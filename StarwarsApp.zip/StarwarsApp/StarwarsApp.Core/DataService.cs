﻿using DogPicApp.Core.Models;
using Newtonsoft.Json;
using StarwarsApp.Core.Models;
using System.Net.Http;
using System.Threading.Tasks;

namespace StarwarsApp.Core
{
    public class DataService
    {
        public static async Task<People> GetStarWarsPeople(string breed)
        {
            var query = "https://dog.ceo/api/breed/" + breed + "/images/random";
            HttpClient client = new HttpClient();
            var response = await client.GetStringAsync(query);

            People data = null;
            if (response != null)
            {
                data = JsonConvert.DeserializeObject<People>(response);
            }
            return data;
        }

        public static async Task<Films> GetStarWarsFilms(string breed)
        {
            string query = "";
            if (breed=="random") { 
                query = "https://dog.ceo/api/breeds/image/random";
            }
            else
            {
                query = "https://dog.ceo/api/breed/" + breed + "/images/random";
            }

            HttpClient client = new HttpClient();
            var response = await client.GetStringAsync(query);

            Films data = null;
            if (response != null)
            {
                data = JsonConvert.DeserializeObject<Films>(response);
            }
            return data;
        }

        public static async Task<Breeds> GetAllBreeds()
        {
            var query = "https://dog.ceo/api/breeds/list/all";
            HttpClient client = new HttpClient();
            var response = await client.GetStringAsync(query);

            Breeds data = null;
            if (response != null)
            {
                data = JsonConvert.DeserializeObject<Breeds>(response);
            }
            return data;
        }

    }
}
