﻿using System.Collections.Generic;

namespace StarwarsApp.Core.Models
{
    public partial class People
    {
        public string Breed { get; set; }
    }
}
