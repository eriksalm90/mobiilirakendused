﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DogPicApp.Core.Models
{
    public partial class Breeds
    {
        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("message")]
        public List<BreedDetails> Message { get; set; }
    }

    public partial class BreedDetails
    {

    }
}

